INSERT INTO `videoparenttype` VALUES (1, '电影', 1, NULL);
INSERT INTO `videoparenttype` VALUES (2, '体育', 1, NULL);
INSERT INTO `videoparenttype` VALUES (3, '娱乐', 2, NULL);
